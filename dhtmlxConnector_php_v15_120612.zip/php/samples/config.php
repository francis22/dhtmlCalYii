<?php
	$mysql_server="192.168.1.251";
	$mysql_user = "sampleDB";
	$mysql_pass = "sampleDB";
	$mysql_db = "sampleDB";
	$excel_file = "../common/excel_sample.xls";
	
	//necessary for PostgreSQL related samples only 
	$postrgre_connection = "host=localhost port=5432 dbname=sampleDB user=root password=1234";
	//necessary for Oracle related samples only 
	$oci_connection = "some here";
	//necessart for SQL Anywhere connection
	$sasql_conn = "uid=DBA;pwd=sql";
?>